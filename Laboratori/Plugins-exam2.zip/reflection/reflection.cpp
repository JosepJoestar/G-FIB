#include "reflection.h"
#include "glwidget.h"
#include <QCoreApplication>

const int IMAGE_WIDTH = 1024;
const int IMAGE_HEIGHT = IMAGE_WIDTH;

struct vertex
{
	GLfloat x, y, z;
};

void Reflection::onPluginLoad()
{
	GLWidget &g = *glwidget();
	g.makeCurrent();
	// Carregar shader, compile & link
	// VS
	vs = new QOpenGLShader(QOpenGLShader::Vertex, this);
	vs->compileSourceFile("reflection.vert");
	//FS
	fs = new QOpenGLShader(QOpenGLShader::Fragment, this);
	// fs->compileSourceFile("reflection.frag");
	fs->compileSourceFile(QCoreApplication::applicationDirPath() +
						  "/../../plugins/reflection/reflection.frag");

	// Program 
	program = new QOpenGLShaderProgram(this);
	program->addShader(vs);
	program->addShader(fs);
	program->link();

	// Setup texture
	g.glActiveTexture(GL_TEXTURE0);
	g.glGenTextures(1, &textureId);
	g.glBindTexture(GL_TEXTURE_2D, textureId);
	g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
					  GL_LINEAR_MIPMAP_LINEAR);
	g.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	g.glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, IMAGE_WIDTH, IMAGE_HEIGHT,
				   0, GL_RGB, GL_FLOAT, NULL);
	g.glBindTexture(GL_TEXTURE_2D, 0);
	// Resize to power-of-two viewport
	g.resize(IMAGE_WIDTH, IMAGE_HEIGHT);
}

void Reflection::preFrame()
{
}

void Reflection::postFrame()
{
	// GLWidget &g = *glwidget();
	// program->bind();
	// g.glBindVertexArray(VAO_base);
	// g.glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	// g.glBindVertexArray(0);
	
	// onPluginLoad();
	paintGL();
}

void Reflection::onObjectAdd()
{
	paintGL();
}

// bool Reflection::drawScene()
// {
// 	// cout << scene()->objects().size()  << endl;
// 	// cout << scene()->objects()[0].faces()[0].normal().x() << endl;
// 	// cout << scene()->objects()[0].vertices()[scene()->objects()[0].faces()[0].vertexIndex(0)].coord() << endl;
// 	for (unsigned int i = 0; i < scene()->objects().size(); ++i)
// 	{
// 		const Object &obj = scene()->objects()[i];
// 		for (unsigned int c = 0; c < obj.faces().size(); c++)
// 		{
// 			const Face &face = obj.faces()[c];
// 			glBegin(GL_POLYGON);
// 			glNormal3f(face.normal().x(), face.normal().y(), face.normal().z());
// 			for (int v = 0; v < face.numVertices(); v++)
// 			{
// 				const Point &p = obj.vertices()[face.vertexIndex(v)].coord();
// 				glVertex3f(p.x(), p.y(), p.z());
// 			}
// 			glEnd();
// 		}
// 	}
// 	return true;
// }

bool Reflection::drawObject(int)
{
	return false; // return true only if implemented
}

void drawRect(GLWidget &g, const Object &obj)
{
	static bool created = false;
	static GLuint VAO_rect;

	// 1. Create VBO Buffers
	if (!created)
	{
		created = true;

		// Create & bind empty VAO
		g.glGenVertexArrays(1, &VAO_rect);
		g.glBindVertexArray(VAO_rect);

		// Create VBO with (x,y,z) coordinates

		// const Object &obj = scene()->objects()[0];

		cout << obj.boundingBox().min() << endl;
		cout << obj.boundingBox().max() << endl;
		auto bmin = obj.boundingBox().min(); 
		auto bmax = obj.boundingBox().max(); 
	
		GLfloat coords[] = {bmin.x(), bmin.y(), bmin.z(),
							bmax.x(), bmin.y(), bmin.z(),
							bmin.x(), bmin.y(), bmax.z(),
							bmax.x(), bmin.y(), bmax.z()};
		// GLfloat coords[] = {-0.5, -1, 0,
		// 					1, -1, 0,
		// 					-0.5, 1, 0,
		// 					0.5, 0.5, 0};

		// GLfloat colors[] = {
		// 	1, 0, 0,
		// 	1, 0, 0, 
		// 	1, 0, 0,
		// 	1, 0, 0,
		// };		

		GLuint VBO_coords; 
		g.glGenBuffers(1, &VBO_coords);
		g.glBindBuffer(GL_ARRAY_BUFFER, VBO_coords);
		g.glBufferData(GL_ARRAY_BUFFER, sizeof(float)*sizeof(coords), &coords[0], GL_STATIC_DRAW);
		g.glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
		g.glEnableVertexAttribArray(0);
		// g.glBindVertexArray(0);
	}

	// 2. Draw
	g.glBindVertexArray(VAO_rect);
	g.glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	g.glBindVertexArray(0);
}


bool Reflection::paintGL()
{
	GLWidget &g = *glwidget();
	// Pass 1. Draw scene
	g.glClearColor(0.8, 0.8, 0.7, 0); 
	g.glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	int selected = scene()->selectedObject();
	const Object &obj = scene()->objects()[selected];
	if (drawPlugin()) {
		// Create & bind empty VAO
		// g.glGenVertexArrays(1, &VAO_obj);
		// g.glBindVertexArray(VAO_obj);  
		// drawPlugin()->drawScene(); 

		program->bind();

		program->setUniformValue("boundingBoxMin", obj.boundingBox().min());
		program->setUniformValue("boundingBoxMax", obj.boundingBox().max());
		program->setUniformValue("colorMap", 0);
		program->setUniformValue("SIZE", float(IMAGE_WIDTH));
		QMatrix4x4 MVP = camera()->projectionMatrix() * camera()->viewMatrix();
		program->setUniformValue("modelViewProjectionMatrix", MVP);
		program->setUniformValue("texture", false);
		program->setUniformValue("inverted", true);
		drawPlugin()->drawScene();
		// vertex *vertices;
		// glEnableClientState(GL_VERTEX_ARRAY);
		// for (unsigned int i = 0; i < scene()->objects().size(); ++i)
		// {
		// 	const Object &obj = scene()->objects()[i];  
		// 	for (unsigned int c = 0; c < obj.faces().size(); c++)
		// 	{
		// 		const Face &face = obj.faces()[c];
		// 		glBegin(GL_POLYGON);
		// 		glColor3f(0.1f, 0.3f, 0.8f);
		// 		glNormal3f(face.normal().x(), face.normal().y(), face.normal().z());
		// 		// vertex *vertices = new vertex[3];
		// 		for (int v = 0; v < face.numVertices(); v++)
		// 		{
		// 			const Point &p = obj.vertices()[face.vertexIndex(v)].coord();
		// 			glVertex3f(p.x(), -p.y(), p.z());
		// 			vertex vtx;	vtx.x = p.x(); vtx.y = -p.y(); vtx.z = p.z();
		// 			// vertices.push_back(vtx); 

		// 			// cout << p.x() << " " << p.y() << " " << p.z() << endl;
		// 		}
		// 		glVertexPointer(3,				// number of coordinates per vertex (x,y,z)
		// 						GL_FLOAT,		// they are floats
		// 						sizeof(vertex), // stride
		// 						vertices);		// the array pointer
		// 		glDrawArrays(GL_POLYGON, 0, 3);
		// 		g.glBindVertexArray(0);
		// 		glEnd(); 
		// 	}
		// }
	}
 

	// Get texture
	g.glBindTexture(GL_TEXTURE_2D, textureId);
	g.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0,
						  IMAGE_WIDTH, IMAGE_HEIGHT);
	g.glGenerateMipmap(GL_TEXTURE_2D);

	// Pass 2. Draw quad using texture
	// g.glClearFr
	g.glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
	program->setUniformValue("inverted", false);

	if (drawPlugin())
	{
		program->bind();
		drawPlugin()->drawScene();

	}
		program->setUniformValue("texture", true);
		// program->setUniformValue("colorMap", 0);
		// program->bind();

		// const Object &obj = scene()->objects()[0];
		// program->setUniformValue("boundingBoxMin", obj.boundingBox().min());
		// program->setUniformValue("boundingBoxMax", obj.boundingBox().max());
		// program->setUniformValue("colorMap", 0);
		// program->setUniformValue("SIZE", float(IMAGE_WIDTH));
		// QMatrix4x4 MVP = camera()->projectionMatrix() * camera()->viewMatrix();
		// program->setUniformValue("modelViewProjectionMatrix", MVP);
		// program->setUniformValue("texture", false);
		// program->setUniformValue("modelViewProjectionMatrix", QMatrix4x4());

		// program->setUniformValue("texture", true);
		drawRect(g, obj);
		program->release();

		g.defaultProgram()->bind();
		g.glBindTexture(GL_TEXTURE_2D, 0);

		return true;
}

void Reflection::keyPressEvent(QKeyEvent *)
{
}

void Reflection::mouseMoveEvent(QMouseEvent *)
{
}
