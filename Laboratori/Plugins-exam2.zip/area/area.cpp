#include "area.h"
#include "glwidget.h"

void Area::onPluginLoad()
{
	
	float area = 0;
	for (auto obj : scene()->objects()) {
		for (auto f : obj.faces()) {
			//for (int i = 0; i < f.numVertices(); ++i) {
			//	++degrees[f.vertexIndex(i)];
			//}
			int v0 = f.vertexIndex(0);
			int v1 = f.vertexIndex(1);
			int v2 = f.vertexIndex(2);
			Point p0 = obj.vertices()[v0].coord();
			Point p1 = obj.vertices()[v1].coord();
			Point p2 = obj.vertices()[v2].coord();
			Vector vec1 = p1-p0;
			Vector vec2 = p2-p0;
			Vector w = Vector::crossProduct(vec1,vec2);
			area += w.length() / 2;
		}
	}
	cout << "Area: " << area << endl;
	
}

void Area::preFrame()
{
	
}

void Area::postFrame()
{
	
}

void Area::onObjectAdd()
{
	
}

bool Area::drawScene()
{
	return false; // return true only if implemented
}

bool Area::drawObject(int)
{
	return false; // return true only if implemented
}

bool Area::paintGL()
{
	return false; // return true only if implemented
}

void Area::keyPressEvent(QKeyEvent *)
{
	
}

void Area::mouseMoveEvent(QMouseEvent *)
{
	
}

